#!/bin/bash
make clean
rm -f output.out
rm -f errors.out
rm -f mdiv.asm
